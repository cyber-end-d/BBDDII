SELECT table_name
FROM user_tables;
