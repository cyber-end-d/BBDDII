CREATE TABLE DEPT
    ID smallint(7),
    NAME varchar(25);
