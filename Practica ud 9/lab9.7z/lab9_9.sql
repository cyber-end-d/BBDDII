COMMENT ON TABLE DEPT
IS 'Departamentos';

COMMENT ON TABLE EMP
IS 'Empleados';

SELECT table_name
FROM user_tables;
