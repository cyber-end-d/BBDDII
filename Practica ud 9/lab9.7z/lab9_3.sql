CREATE TABLE EMP
    ID smallint(7),
    LAST_NAME varchar(25),
    FIRST_NAME varchar(25),
    DEPT_ID smallint(7);
