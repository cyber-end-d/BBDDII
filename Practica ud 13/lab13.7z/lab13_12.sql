SELECT table_name, owner
FROM all_tables;
