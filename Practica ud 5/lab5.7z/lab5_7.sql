SELECT COUNT(MANAGER_ID) AS 'Number of managers'
FROM employees;