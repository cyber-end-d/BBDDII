SELECT constraint_name, constraint_type
FROM user_constraints;
