SELECT CONCAT(LAST_NAME, ' earns ', SALARY, ' monthly, but wants ', (SALARY*3)) AS 'Dream salaries'
FROM employees;