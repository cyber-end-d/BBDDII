INSERT INTO MY_EMPLOYEE
VALUES
    (1, 'Patel', 'Ralph', 'rpatel', 895);

