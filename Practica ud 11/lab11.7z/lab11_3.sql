SELECT view_name, text
FROM user_views;
